# Ángel Guardián · Demo B2B

Abre `dist/index.html` con doble clic. No requiere instalación ni servidor. También puedes servir la carpeta `dist` con cualquier servidor web estático.

## Recorrido comercial sugerido (5 minutos)

1. Presentación: “Cada persona. Cada trayecto. Siempre visible.” Explica la diferencia entre ubicar un vehículo y confirmar el traslado de cada persona.
2. Abre la plataforma: muestra los indicadores, el mapa ilustrativo y las tres unidades ficticias.
3. Entra a **Traslado demo** y pulsa **Reiniciar demo** para empezar desde programación.
4. Abre el abordaje. Prueba un registro individual NFC o QR y luego **Cargar 11 abordajes de ejemplo**.
5. Confirma la salida: DEMO-012 queda ausente y genera una alerta.
6. Simula un descenso fuera de punto, un desvío o un retraso. Abre Alertas, revisa una incidencia y registra una resolución.
7. Regresa al traslado, registra la llegada y confirma los descensos. El cierre se bloquea si quedan pasajeros a bordo.
8. Consulta el manifiesto, abre el historial de una persona y descarga un CSV desde Reportes. Puedes imprimir o guardar el reporte en PDF desde el navegador.

## Qué incluye

Landing, dashboard, manifiestos por unidad, búsqueda y filtros, identificación simulada NFC/QR, cinco etapas del viaje, timeline, cuatro tipos de alertas, resolución con nota, historial de eventos, reportes CSV, impresión y configuración del turno y tolerancia.

Diseño adaptable a escritorio y móvil, navegación lateral y menú móvil. La ruta usa un esquema SVG ilustrativo, no cartografía ni distancias reales.

## Alcance

Es una demostración de interfaz y flujo, no un sistema operativo de seguridad. No conecta GPS, cámaras, lectores NFC, credenciales de empleados ni servicios de mensajería. Las personas, empresas, unidades y eventos son ficticios. Los cambios duran durante la sesión de la página; recargar restablece el escenario inicial en ruta. No hay backend ni inicio de sesión en los archivos locales.

Los archivos funcionan sin internet; si Google Fonts no está disponible, se utilizan las tipografías del sistema. Los CSV se generan localmente. La publicación remota no se completó: el complemento instalado no contiene el archivo de publicación requerido. La versión local funciona de forma independiente.

## Archivos

- `dist/index.html`: entrada de la web.
- `dist/style.css`: estilos responsive.
- `dist/app.js`: datos y lógica de la simulación.
- `.openai/hosting.json`: configuración de publicación en Sites.

## Validación

Sintaxis JavaScript verificada. Recorrido de programación a cierre probado en navegador, incluido el bloqueo del cierre con pasajeros a bordo. Datos enlazados entre manifiesto, incidencias, timeline e indicadores.
